#define _ALIGN(x) __attribute__ ((aligned(x)))

extern void debuglog_hex(void *data, int len);

